var game = new Object()
var existsGame = false;
Array.prototype.includes = function (n) {
    for (var i = 0; i < this.length; i++) {
        if (this[i] == n) return true
    }
    return false
}
function log(userobj, text) {
    if (!userobj)
        print("\x0302\x06Juego del Ahorcado\x06 | " + text)
    print(userobj, "\x030\x062Juego del Ahorcado\x06 | " + text)
}

function onLoad() {
    print("\x0302Juego del Ahorcado by nokia - \x06v1.0.4")
}

function onPart(userobj) {
    if (!existsGame) return
    if (!(userobj.id in game.players)) return
    delete game.players[userobj.id]
    delete game.points[userobj.id]
    var numPlayers = Object.keys(game.players).length
    log(null, "\x0304" + userobj.name + " ha abandonado la partida, " + numPlayers + " jugador(es)")
    if (numPlayers < 2) {
        log(null, "\x0304Se termina la partida por falta de jugadores")
        endGame()
    }
}

function onCommand(userobj, cmd, target, args) {
    switch (true) {
        case cmd.indexOf("helpahorcado") == 0:
            help(userobj)
            break
        case cmd.indexOf("nuevojuego") == 0:
            if (existsGame) {
                log(null, "Ya existe una partida creada por " + user(game.owner).name)
                return
            }
            initGame()
            game.owner = userobj.id
            log(null, "Nueva partida creada por " + userobj.name)
            existsGame = true;
            break
        case cmd.indexOf("palabrajuego") == 0:
            setWordGame(userobj, cmd)
            break
        case cmd.indexOf("entrarjuego") == 0:
            addPlayer(userobj)
            break
        case cmd.indexOf("empezarjuego") == 0:
            startGame(userobj)
            break
        case cmd.indexOf("terminarjuego") == 0:
            if (!existsGame) {
                log(null, "No se ha creado una partida")
                return
            }
            if (userobj.id != game.owner) {
                log(null, "\x0304Solo el anfitrión de la partida puede terminarla")
                return
            }
            endGame()
            break
    }
}

function onTextAfter(userobj, txt) {
    if (!existsGame) return
    if (!game.isStarted) return
    var playersArray = Object.keys(game.players)
    var playerSelected = playersArray[game.currentPositon]
    var numPlayers = playersArray.length
    var text = txt.replace(/\x06|\x09|\x07|\x03[0-9]{2}|\x05[0-9]{2}/g, "");
    text = text.toLowerCase()
    if (text.indexOf("?") == 0) {
        if (!playersArray.includes(userobj.id)) return
        var tryWord = text.split("?")[1]
        tryWord(userobj, tryWord)
    }
    if (playerSelected == userobj.id) {
        if (text.length != 1) {
            log(null, userobj.name + " debes decir solo una letra")
            return
        }
        if (!game.validChars.includes(text)) {
            log(null, userobj.name + " letra no valida")
            return
        }
        game.currentPositon = game.currentPositon + 1
        if (game.currentPositon >= numPlayers)
            game.currentPositon = 0
        if (!game.usedChars.includes(text)) {
            game.usedChars.push(text)
            validateChar(text, userobj)
        } else
            log(null, userobj.name + " \x0304ya se usó la letra \x06" + text)
        playGame()
    }
}

function initGame() {
    game.isStarted = false
    game.players = new Object()
    game.points = new Object()
    game.currentPositon = 0
    game.usedChars = new Array()
    game.validChars = new Array("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "ñ", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z");
    game.word = ""
    game.errors = 0
}

function setWordGame(userobj, cmd) {
    if (!existsGame) {
        log(userobj, "No se ha creado una partida")
        return
    }
    if (game.owner != userobj.id) {
        log("Solo el anfitrión de la partida puede configurar la palabra")
        return
    }
    if (game.isStarted) {
        log(userobj, "No se puede cambiar la palabra una vez que se inició la partida")
        return
    }
    var text = cmd.replace(/\x06|\x09|\x07|\x03[0-9]{2}|\x05[0-9]{2}/g, "");
    var word = text.split(" ")[1]
    if (!word || word == "") {
        log(userobj, "Palabra inválida")
        return
    }
    if (word.length < 5) {
        log(userobj, "Palabra inválida, debe tener mínimo 5 letras")
        return
    }
    log(userobj, "\x0314Se configuró la palabra " + word)
    game.word = word
}

function tryWord(userobj, cmd) {
    if (!existsGame) {
        log(userobj, "No se ha creado una partida")
        return
    }
    if (!game.isStarted) {
        log(userobj, "No se iniciado la partida")
        return
    }
    var word = cmd.split(" ")[1]
    if (!word || word == "") {
        log(userobj, "Palabra inválida")
        return
    }
    if (word == game.word) {
        game.points[userobj.id] = game.points[userobj.id] + 5
        log(null, "(H) \x0310\x06" + userobj.name + " \x06\x0302adivinó la palabra (H), la palabra era \x06\x0304" + word)
        endGame()
    } else {
        log(null, userobj.name + " buen intento, pero \x06\x0304" + word + "\x06\x0302 no es la palabra")
    }
}

function addPlayer(userobj) {
    if (!existsGame) {
        log(userobj, "No se ha creado una partida para unirse")
        return
    }
    if (game.isStarted) {
        log(userobj, "La partida ya ha empezado, no puede unirse")
        return
    }
    if (game.owner == userobj.id) {
        log(userobj, "El anfitrión de la partida no puede jugar")
        return
    }
    if (!!game.players[userobj.id]) {
        log(userobj, "Ya te has unido a la partida")
        return
    }
    userobj.isPlaying = true
    game.players[userobj.id] = userobj
    game.points[userobj.id] = 0
    var numPlayers = Object.keys(game.players).length
    log(null, userobj.name + " se ha unido a la partida, " + numPlayers + " jugador(es) en total")
}

function startGame(userobj) {
    if (!existsGame) {
        log(userobj, "No se ha creado una partida para iniciar")
        return
    }
    if (game.isStarted) {
        log(userobj, "La partida ya ha empezado")
        return
    }
    if (game.owner != userobj.id) {
        log(userobj, "Solo el anfitrión de la partida inciarla")
        return
    }
    if (!game.word) {
        log(userobj, "No se puede iniciar la partida, no ha definido la palabra")
        return
    }
    var playersArray = Object.keys(game.players)
    var numPlayers = playersArray.length
    if (numPlayers < 2) {
        log(null, "No se puede iniciar la partida, debe haber mínimo dos jugadores")
        return
    }
    game.isStarted = true
    log(null, "Juego del Ahorcado | La partida ha empezado")
    playGame()
}

function playGame() {
    var playersArray = Object.keys(game.players)
    var playerSelected = playersArray[game.currentPositon]
    log(null, "\x0310\x06" + game.players[playerSelected].name + "\x06\x0302 es tu turno, arroja una letra")
    showWord()
}

function showPoints() {
    var playersArray = Object.keys(game.players)
    log(null, "Puntajes:")
    var maxPoints = 0;
    var winnerId = null;
    for (var i = 0; i < playersArray.length; i++) {
        var player = game.players[playersArray[i]]
        if (game.points[player.id] > maxPoints) {
            maxPoints = game.points[player.id]
            winnerId = player.id
        }
        var points = getPoints(game.points[player.id])
        print("\x0302- " + player.name + ": " + points)
    }
    var winnerPoints = getPoints(maxPoints)
    log(null, "Ganador de la partida: (H)(H)(H) \x06" + game.players[winnerId].name + " (H)(H)(H), \x06Puntaje final: " + winnerPoints)
}

function getPoints(points) {
    var starIcon = "(*)"
    var string = ""
    for (var j = 0; j < points; j++)
        string = string + starIcon
    return string
}

function showWord() {
    var chars = game.word.split("")
    var string = "\x0301"
    for (var i = 0; i < chars.length; i++) {
        if (game.usedChars.includes(chars[i]))
            string = string + " " + chars[i] + " "
        else
            string = string + " __ "
    }
    log(null, string)
}

function validateChar(text, userobj) {
    var chars = game.word.split("")
    if (chars.includes(text)) {
        game.points[userobj.id] = game.points[userobj.id] + 1
        var points = getPoints(game.points[userobj.id])
        log(null, "\x0303Correcto " + userobj.name + ", Puntaje: " + points)
    } else {
        game.errors = game.errors + 1
        log(null, "\x0304Incorrecto, " + game.errors + " error(es) de 6")
        var scribbleName = "step" + game.errors + ".jpg"
        var scribble = new Scribble().load(scribbleName)
        Users.local(function (user) {
            user.scribble(scribble)
        })
        if (game.errors >= 6) {
            log(null, "\x0301Fin del juego, la palabra era \x06" + game.word)
            endGame()
        }
    }
}

function endGame() {
    existsGame = false
    showPoints()
    initGame()
    log(null, "Partida terminada")
}

function help(userobj) {
    print(userobj, "#nuevojuego")
    print(userobj, "#empezarjuego")
    print(userobj, "#terminarjuego")
    print(userobj, "#palabrajuego palabra | Para configurar la palabra, 5 letras mínimo")
    print(userobj, "?palabra | Para adivinar la palabra")
    print(userobj, "#entrarjuego | Para unirse a la partida")
}

function onHelp(userobj) {
    print(userobj, "#helpahorcado | Comandos juego del ahorcado")
}
