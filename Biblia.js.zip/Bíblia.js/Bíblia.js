print("Consultor de Bíblia carregado v1.0");

var style = {
	'bold': "\x06",
	'italic': "\x09",
	'underline': "\x07",
	'forground': {
		'black': "\x0301",
		'blue': "\x0312"
	}
}
function onCommand(userobj, command, target, args) {
	if(command.indexOf("Bíblia") != 0)
		return;
	
	args = command.substr(6);
	
	var http = new HttpRequest();
	http.src = "https://getbible.net/json?scrip=" + encodeURI(args) + "&version=almeida";
	http.userAgent = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36";
	
	http.oncomplete = function (e) {
		if(e) {
			var obj = JSON.parse(this.page.substring(1, this.page.length - 2));
			var bookName = obj.book[0].book_name;
			var chapterNum = obj.book[0].chapter_nr
			
			for(var i in obj.book[0].chapter) {
				var verseNum = obj.book[0].chapter[i].verse_nr;
				var verse = obj.book[0].chapter[i].verse;
				var chapterVerseNum = chapterNum + ":" + verseNum;
				
				var text = style.bold + style.italic + style.underline;
				text = text + style.forground.black;
				text = text + bookName;
				text = text + style.italic + style.underline
				text = text + " ";
				text = text + chapterVerseNum;
				text = text + " ";
				text = text + style.forground.blue;
				text = text + verse;
				
				
				print(userobj.vroom, text);
			}
		}
		else {
			print("Unable to get data from site");
		}
	};
	
	http.download();
}