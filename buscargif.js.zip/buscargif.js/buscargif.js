print("\x0314 buscargif script loaded v1.0 by nokia");

function onTextBefore(userobj, text) { 
	var command=text.split(" ");
	if(command[0][0]!=="#"){
		return text;
	}else{return "";}	
 
}
function onTextReceived(userobj,text){
	var command=text.split(" ");
	if(command[0]==="#gif"){
		buscarGif(command[1],userobj);
		//print("\x0314"+text);
	}
}
function buscarGif(tema,userobj){
var httpg = new HttpRequest();
httpg.src ="https://api.tenor.com/v1/search?q="+tema+"&key=GTOMGA48BTYS&limit=8";
httpg.oncomplete = function (e)
{
	if(e){
		var result=this.page;
		var json=JSON.parse(result);
		var select=Math.floor((Math.random() * 7) + 0);
		descargarGif(json.results[select].media[0].gif.url,userobj);
	}
}

httpg.download();
}
function descargarGif(url,userobj){
	    var scribble = new Scribble();
            scribble.src = url;
            scribble.oncomplete = function (e) {
    		if (e) {
        		var gif = this;
        		var name = this.arg;
			print("\x0314--- From " + name);
       			Users.local(function(u) {
			if (u.canHTML){
				u.sendHTML("<img src="+url+" width='auto' height='auto' />")
			}else{
				u.scribble(gif,url);
			}
        		});
    		} else print("unable to download " + this.arg + "'s scribble - check link and try again!");
	}
        scribble.download(userobj.name);
}
function scribbleReceived(e) {
    if (e) {
        var gif = this;
        var name = this.arg;

        Users.local(function(u) {
            /*var ignores = u.ignores;

            var canShow = true;

            for (var i = 0; i < ignores.length; i++) {
                if (ignores[i].name == name)
                    canShow = false;
            }*/

            //if (canShow) {
                print(u, "\x0314--- From " + name);
                u.scribble(gif);
            //}
        });
    } else print("unable to download " + this.arg + "'s scribble - check link and try again!");
}