function onLoad(){
	print("\x0314Flags-Country Blocker by nokia24.");
	loadWhitelist();
}
var whitelist=[];
var filename="whitelist.txt";
var deteccionpaises = false;

function loadWhitelist(){
	if (File.exists(filename)){
		var str = File.load(filename);
		whitelist=str.split(",");
		if (whitelist.length>0)
			print("\x0314 White list de paises cargada");
	}
		
}
function saveWhitelist(){
	File.save(filename,whitelist.join(","));
}

function allowCountry(code){
	if(whitelist.indexOf(code)>=0){
		print("\x0314 País ya existe en white list");return;
	}
	whitelist.push(code);
	saveWhitelist();
	print("\x0314 País "+code+" agregado");
}

function removeCountry(code){
	if(whitelist.indexOf(code)<0){
		print("\x0314 País no existe en white list");return;
	}
	whitelist = whitelist.filter(function(val, index, a) {
    		return (val != code);
 	});
	saveWhitelist();
	print("\x0314 País "+code+" eliminado");
}

function watchWhitelist(){
	print("\x0314 White list: "+whitelist.join(" "));
}

function onCommand(userobj, command, args){
	if(userobj.level==0)
		return;
	if(command.indexOf("blockcountrys on") == 0){
		print("\x0314" + userobj.name + " activó bloqueo de paises");
		deteccionpaises = true;
	}else if(command.indexOf("blockcountrys off") == 0){
		print("\x0314" + userobj.name + " desactivó bloqueo de paises");
		deteccionpaises = false;
	}else if(command.indexOf("allowcountry") == 0){
		var options=command.split(" ");
		if (options.length==1){
			print("\x0314 Se necesita el código del país");return;
		}
		var code=options[1];
		if(code.length!=2){
			print("\x0314 Código de país incorrecto");return;
		}
		allowCountry(code.toUpperCase());watchWhitelist();
	}else if(command.indexOf("removecountry") == 0){
		var options=command.split(" ");
		if (options.length==1){
			print("\x0314 Se necesita el código del país");return;
		}
		var code=options[1];
		removeCountry(code.toUpperCase());watchWhitelist();
	}else if(command.indexOf("watchwhitelist") == 0){
		watchWhitelist();
	}
	
}
function onJoin(u){
	
	trace = new HttpRequest();
	trace.src = "http://ip-api.com/json/"+u.externalIp
   trace.utf = true
	trace.oncomplete = function(){ 
		var prueba = JSON.parse(this.page);
		if(prueba.status==="success"){
			if(deteccionpaises && whitelist.indexOf(prueba.countryCode.toUpperCase())===-1 && u.level<1){
				print("\x0314País de " +  u.name + " (" +prueba.country+ ") no está en la white list");
				user(u.id).ban();
			}else{
				mostrar(prueba.countryCode.toLowerCase(),prueba.country,u.name);
			}
		}
	}
	trace.download();
	
}



function mostrar(code,pais,user) {
    var x = new Scribble();
	  var url= "http://sorrow-sb0t.webs.com/" + code + ".gif";
    x.src =url;
    x.oncomplete = function (e) {
      if(e){
        var p = this;
        Users.local(function(i){
    		  if (i.canHTML){
    			  i.sendHTML("<img src="+url+" width='auto' height='auto' />");
    		  }else{
    			  i.scribble(p,url);
    		  }       
        });
      }
    };
    x.download(user);
}
function onHelp(userobj) {
	if (userobj.level > 0) {
		print(userobj, "#blockcountrys <on/off> --- activa/desactiva el bloqueo de paises");
		print(userobj, "#allowcountry code ---- permite un país por código de país (PE,EC,AR,RD)");
		print(userobj, "#removecountry code ---- bloquea un país por código de país (PE,EC,AR,RD)");
		print(userobj, "#watchwhitelist ---- lista de paises permitidos");
	}
}