# partybomb.js
Juego para Ares similar al Partybomb web.

Script compatible con el servidor: sb0t.
