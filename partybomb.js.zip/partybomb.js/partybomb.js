include('command.js');
include('file.js');
function onLoad(){
    openFile();
    print('\x0301Partybomb.js by Manu16');
    print('\x0301Script onLoad...(O)');
}