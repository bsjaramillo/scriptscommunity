
function UserPlayer(Name){
    this.name=Name;
    this.vroom=1;
    this.life=2;
    this.isDead=false;
}