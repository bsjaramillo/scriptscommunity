Array.prototype.includes = function (n) {
    for (var i = 0; i < this.length; i++) {
        if (this[i] == n) return true
    }
    return false
}

function onHelp(userobj) {
    print(userobj, "#helpquotes | Comandos Quotes Script")
}

function onLoad() {
    print("\x0302Quotes by nokia - \x06v1.0.0")
}

function onCommand(userobj, cmd, target, args) {
    switch (true) {
        case cmd.indexOf("addquote") == 0:
            addQuote(userobj, cmd)
            break
        case cmd.indexOf("quotes") == 0:
            showQuotes(userobj)
            break
        case cmd.indexOf("delquote") == 0:
            if (userobj.level < 1) {
                log(userobj, "\x0304No tienes permisos para usar este comando")
                return
            }
            deleteQuote(userobj, cmd)
            break
        case cmd.indexOf("remquotes") == 0:
            if (userobj.level < 1) {
                log(userobj, "\x0304No tienes permisos para usar este comando")
                return
            }
            deleteQuotes(userobj)
            break
        case cmd.indexOf("helpquotes") == 0:
            help(userobj)
            break
    }
}

function deleteQuotes(userobj) {
    File.kill("quotes.txt")
    log(userobj, "\x0303\x06Frases borradas correctamente")
}

function deleteQuote(userobj, args) {
    var id = args.substr(9, args.length)
    var currentQuotes = loadQuotes()
    var quotesLength = Object.keys(currentQuotes).length
    if (quotesLength == 0) {
        log(userobj, "No hay frases guardadas")
        return
    }
    if (id == null || id == "") {
        log(userobj, "\x0304Debes escribir una id")
        return
    }
    if (isNaN(id)) {
        log(userobj, "\x0304La id debe ser un número")
        return
    }
    if (currentQuotes[id] == null) {
        log(userobj, "\x0304La id no existe")
        return
    }
    id = parseInt(id)
    var j = 0
    File.kill("quotes.txt")
    for (var i = 0; i < quotesLength; i++) {
        if (id == i) continue
        if (!File.exists("quotes.txt")) {
            File.save("quotes.txt", j + ";" + currentQuotes[i].user + ";" + currentQuotes[i].quote)
            j = j + 1
            continue
        }
        File.append("quotes.txt", "\n" + j + ";" + currentQuotes[i].user + ";" + currentQuotes[i].quote)
        j = j + 1
    }
    log(userobj, "\x0303\x06Frase borrada correctamente")
}

function addQuote(userobj, args) {
    var text = args.substr(9, args.length)
    var currentQuotes = loadQuotes()
    var currentQuoteId = Object.keys(currentQuotes).length
    if (text.length < 1 || text == null || text == "") {
        log(userobj, "\x0304Debes escribir una frase")
        return
    }
    var resp = false;
    if (File.exists("quotes.txt")) {
        resp = File.append("quotes.txt", "\n" + currentQuoteId + ";" + userobj.name + ";" + text)
    } else {
        resp = File.save("quotes.txt", currentQuoteId + ";" + userobj.name + ";" + text)
    }
    if (resp) {
        log(userobj, "\x0303\x06Frase añadida correctamente")
    } else {
        log(userobj, "\x0304\x06Error al añadir la frase")
    }
}

function loadQuotes() {
    var quotes = new Object()
    if (!File.exists("quotes.txt")) {
        return quotes
    }
    var lines = File.load("quotes.txt").split("\n")
    for (var i = 0; i < lines.length; i++) {
        var quote = lines[i].split(";")
        quotes[i] = new Object()
        quotes[i].id = quote[0]
        quotes[i].user = quote[1]
        quotes[i].quote = quote[2]
    }
    return quotes
}

function showQuotes(userobj) {
    var currentQuotes = loadQuotes()
    var quotesLength = Object.keys(currentQuotes).length
    if (quotesLength == 0) {
        log(userobj, "No hay frases guardadas")
        return
    }
    for (var i = 0; i < quotesLength; i++) {
        log(userobj, "\x0302\x06[" + currentQuotes[i].id + "]\x06 " + currentQuotes[i].user + " (P) > \x03: " + currentQuotes[i].quote)
    }
}

function help(userobj) {
    print(userobj, "#addquote frase | Para añadir una frase")
    print(userobj, "#quotes | Para ver las frases guardadas")
    if (userobj.level >= 1) {
        print(userobj, "#delquote id | Para borrar una frase")
        print(userobj, "#remquotes | Para borrar todas las frases")
    }
}

function log(userobj, text) {
    if (!userobj)
        print("\x0302\x06Quotes\x06 | " + text)
    else
        print(userobj, "\x0302\x06Quotes\x06 | " + text)
}