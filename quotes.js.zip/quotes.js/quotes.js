Array.prototype.includes = function (n) {
    for (var i = 0; i < this.length; i++) {
        if (this[i] == n) return true
    }
    return false
}
var dbName = "quotes.db"

function onHelp(userobj) {
    print(userobj, "#helpquotes | Comandos Quotes Script")
}

function onLoad() {
    print("\x0302Quotes by nokia - \x06v1.0.0")
}

function onCommand(userobj, cmd, target, args) {
    switch (true) {
        case cmd.indexOf("addquote") == 0:
            addQuoteQuery(userobj, cmd)
            break
        case cmd.indexOf("quotes") == 0:
            showQuotes(userobj)
            break
        case cmd.indexOf("delquote") == 0:
            if (userobj.level < 1) {
                log(userobj, "\x0304No tienes permisos para usar este comando")
                return
            }
            deleteQuoteQuery(userobj, cmd)
            break
        case cmd.indexOf("remquotes") == 0:
            if (userobj.level < 1) {
                log(userobj, "\x0304No tienes permisos para usar este comando")
                return
            }
            deleteQuotesQuery(userobj)
            break
        case cmd.indexOf("helpquotes") == 0:
            help(userobj)
            break
    }
}

function getQuotesQuery() {
    var quotes = new Object()
    var queryString = "SELECT * FROM quotes"
    var query = new Query(queryString)
    var sql = new Sql()
    sql.open(dbName)
    if (sql.connected) {
        sql.query(query)
        while (sql.read) {
            var id = sql.value("id")
            var user = sql.value("user")
            var quote = sql.value("quote")
            quotes[id] = new Object()
            quotes[id].id = id
            quotes[id].user = user
            quotes[id].quote = quote
        }
        sql.close()
    } else {
        log(null, "\x0304\x06Error al conectar con la base de datos:\x06" + sql.lastError)
    }
    return quotes
}

function deleteQuotesQuery(userobj) {
    var queryString = "DELETE FROM quotes"
    var query = new Query(queryString)
    var sql = new Sql()
    sql.open(dbName)
    if (sql.connected) {
        sql.query(query)
        sql.close()
        log(userobj, "\x0303\x06Frases borradas correctamente")
    } else {
        log(userobj, "\x0304\x06Error al borrar las frases")
    }
}

function deleteQuoteQuery(userobj, args) {
    var id = args.substr(9, args.length)
    var currentQuotes = getQuotesQuery()
    var quotesLength = Object.keys(currentQuotes).length
    if (quotesLength == 0) {
        log(userobj, "No hay frases guardadas")
        return
    }
    if (id == null || id == "") {
        log(userobj, "\x0304Debes escribir una id")
        return
    }
    if (isNaN(id)) {
        log(userobj, "\x0304La id debe ser un número")
        return
    }
    if (currentQuotes[id] == null) {
        log(userobj, "\x0304La id no existe")
        return
    }
    id = parseInt(id)
    var queryString = "DELETE FROM quotes WHERE id = {0}"
    var query = new Query(queryString, id)
    var sql = new Sql()
    sql.open(dbName)
    if (sql.connected) {
        sql.query(query)
        sql.close()
        log(userobj, "\x0303\x06Frase borrada correctamente")
    } else {
        log(userobj, "\x0304\x06Error al borrar la frase")
    }
}

function addQuoteQuery(userobj, args) {
    var text = args.substr(9, args.length)
    if (text.length < 1 || text == null || text == "") {
        log(userobj, "\x0304Debes escribir una frase")
        return
    }
    var queryString = "INSERT INTO quotes (user, quote) VALUES ({0},{1})"
    var query = new Query(queryString, userobj.name, text)
    var sql = new Sql()
    sql.open(dbName)
    if (sql.connected) {
        sql.query(query)
        sql.close()
        log(userobj, "\x0303\x06Frase añadida correctamente")
    } else {
        log(userobj, "\x0304\x06Error al añadir la frase")
    }
}

function showQuotes(userobj) {
    var currentQuotes = getQuotesQuery()
    var quotesKeys = Object.keys(currentQuotes)
    var quotesLength = quotesKeys.length
    if (quotesLength == 0) {
        log(userobj, "No hay frases guardadas")
        return
    }
    for (var i = 0; i < quotesLength; i++) {
        var key = quotesKeys[i]
        log(userobj, "\x0302\x06[" + currentQuotes[key].id + "]\x06 " + currentQuotes[key].user + " (P) > \x03: " + currentQuotes[key].quote)
    }
}

function help(userobj) {
    print(userobj, "#addquote frase | Para añadir una frase")
    print(userobj, "#quotes | Para ver las frases guardadas")
    if (userobj.level >= 1) {
        print(userobj, "#delquote id | Para borrar una frase")
        print(userobj, "#remquotes | Para borrar todas las frases")
    }
}

function log(userobj, text) {
    if (!userobj)
        print("\x0302\x06Quotes\x06 | " + text)
    else
        print(userobj, "\x0302\x06Quotes\x06 | " + text)
}