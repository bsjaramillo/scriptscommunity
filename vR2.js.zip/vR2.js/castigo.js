include('users.js');

var infractores = [];
var baneados = [];
function infractor(name){
    return {
        name:name,
        count:0,
    }
}

function addInfracion(name){
    var index;
    var isInfractor = infractores.some(function(inf,indice){
       if(inf.name === name){ 
        index=indice
        return true
    }
    })

    if(isInfractor){
        infractores[index].count += 1;

        if(infractores[index].count > 3){
                remUser(name);
                sendAllMessage(" Ha sido hechado del juego por incumplir mas de 3 veces con el juego");
                baneados.push(infractores[index]);
        } else {
            sendAllMessage(" tiene una nueva infracción mucho ojo, si no jugas bien te hecho :@");
        }
    }  else{
        var newInfractor = infractor(name);
        infractores.push(newInfractor);
        sendAllMessage("ya tienes 1, si pasas la 3 a la calle.");
    }
}

function remBan(name){
    baneados = baneados.filter(function(infractor){
        return infractor.name !== name
    })
    sendAllMessage(name+" ha sido desbaneado del juego");
}