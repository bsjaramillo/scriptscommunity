var commands = [
"#addReto +reto       ------> Para Agregar un reto",
"#remReto +id         ------> Para Eliminar un Reto",
"#addVerdad +verdad   -----> Para Agregar una Verdad",
"#remVerdad +id      -------> Para Eliminar una Verdad",
"#listRetos         -------> Para ver la Lista de Retos",
"#listVerdades      -------> Para ver la lista de Verdades",
"#startGame         -------> Para comenzar el juego(necesita min 2 participantes)",
"#stopGame          -------> Para detener el juego",
"#unirme             -------> Para ingresar al juego",
"#salirme            -------> Para salirse del juego",
"#cumplio            -------> Para votar si cumplio con el juego",
"#nocumplio          -------> Para votar si cumplio con el juego",
"#timeRes +s         -------> Para cambiar el tiempo para responde al verdad o reto",
"#timeCumplir +s     -------> Para cambiar el tiempo para cumplir con el reto, o responder la verdad",
"#timeVot +s         -------> Para cambiar el tiempo de la votación."
];


function onHelp(user){
    print(user,"################# Comandos del juego Verdadero o Reto ################")
    commands.forEach(function(comand){
        print(user, comand)
    })
    print(user,"################# Comandos del juego Verdadero o Reto ################")
}

include('game.js');
include('users.js');


function onCommand(user,cmd,target,args){
        if(cmd.substr(0,9)==='addVerdad'){
            var arg = cmd.substr(10);
            addVerdad(arg);
        }
        if(cmd.substr(0,7)==='addReto'){
            var arg = cmd.substr(8);
            addReto(arg);
        }
        if(cmd.substr(0,7)=='remReto'){
            var arg = cmd.substr(8);
            remReto(arg)
        }
        if(cmd.substr(0,9)=='remVerdad'){
            var arg = cmd.substr(10);
            remVerdad(arg)
        }
        if(cmd === "startGame"){
            startGame();
        }

        if(cmd==="stopGame"){
            stopGame();
        }
        if(cmd==="listRetos"){
            listRetos();
        }
        if(cmd==="listVerdades"){
            listVerdades();
        }
        if(cmd.substr(0,6)==="unirme"){
            addUser(user.name);
        }
        if(cmd.substr(0,7)==="salirme"){
            remUser(user.name)
        }

        if(cmd==='cumplio'){
            print(user.name+" ha votado")
            sendVoto(1);
        } 
        if(cmd==='nocumplio') {
            print(user.name+" ha votado")
            sendVoto(-1);
        }
        if(cmd.substr(0,7)==='timeRes' && user.level>=1){
            var arg = cmd.substr(8);
            changeTime(parseInt(arg),"res");
        }
        if(cmd.substr(0,11)==='timeCumplir' && user.level>=1){
            var arg = cmd.substr(12);
            changeTime(parseInt(arg),"cumplir");
        }
        if(cmd.substr(0,7)==='timeVot' && user.level>=1){
            var arg = cmd.substr(8);
            changeTime(parseInt(arg),"vot");
        }

      if(cmd==="vrHelp"){
        print(user,"################# Comandos del juego Verdadero o Reto ################")
        commands.forEach(function(comand){
            print(user, comand)
        })
        print(user,"################# Comandos del juego Verdadero o Reto ################")
      }

}