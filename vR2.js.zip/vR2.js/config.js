var TIEMPO_RESPUESTA 
var TIEMPO_VOTACION 
var TIEMPO_CUMPLIR_RETO 

function loadConfig(){
    if(File.exists('config.json')){
        var fs = File.load('config.json');
        var config = JSON.parse(fs);
        TIEMPO_CUMPLIR_RETO = config.TIEMPO_CUMPLIR_RETO;
        TIEMPO_RESPUESTA = config.TIEMPO_RESPUESTA;
        TIEMPO_VOTACION = config.TIEMPO_VOTACION;
    }
}

loadConfig();

function changeTime(s, action) {
  switch (action) {
    case "res":
      TIEMPO_RESPUESTA = s;
      print("Se ha establecido el tiempo de respuesta en " + s + " segundos");
      saveConfig();
      return;
    case "vot":
      TIEMPO_VOTACION = s;
      print("Se ha establecido el tiempo de votacion en " + s + " segundos");
      saveConfig();
      return;
    case "cumplir":
      TIEMPO_CUMPLIR_RETO = s;
      print(
        "Se ha establecido el tiempo de cumplir con el juego en " +
          s +
          " segundos"
      );
      saveConfig();
      return;
  }
  
}

function saveConfig() {
  if (File.exists("config.json")) {
    File.save("config.json",
      JSON.stringify({
        TIEMPO_RESPUESTA:TIEMPO_RESPUESTA,
        TIEMPO_VOTACION: TIEMPO_VOTACION,
        TIEMPO_CUMPLIR_RETO: TIEMPO_CUMPLIR_RETO,
      })
    );
  }
}




