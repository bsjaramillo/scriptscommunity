  // constantes
  include('users.js')
  include('config.js')
    var SELECT_PLAYER ="SELECT_PLAYER"
    var SEND_OPTION = "SEND_OPTION"
    var GET_REQUEST = "GET_REQUEST"
    var CHANGE_PLAYER="CHANGE_PLAYER"
    var SEND_RETO="SEND_RETO"
    var SEND_VERDAD="SEND_VERDAD"
    var GET_RESPONSE="GET_RESPONSE"
    var SEND_VOTE="SEND_VOTE"
    var CHECK_VOTE="CHECK_VOTE"




var currentAction;

function sendOption(){
    currentAction = false;
    if(currentUser){
        Players.forEach(function(player){
            print(user(player), currentUser+" Verdad o Reto? tienes ");
        });
        currentAction = GET_REQUEST;
        counter=TIEMPO_RESPUESTA;
    }
}

function changePlayer(){
    currentAction = false;
    Players.forEach(function(player){
        print(user(player), currentUser+' No ha logrado contestar a tiempo, Eligiendo a otro');
        // addInfracion(currentUser);
    });
    currentAction = SELECT_PLAYER;
}


function sendMessage(message){
    Players.forEach(function(player){
        print(user(player), currentUser+" "+message);
    })
    currentAction = GET_RESPONSE;
    counter=TIEMPO_CUMPLIR_RETO;
}

function sendAllMessage(message){
    Players.forEach(function(player){
        print(user(player), currentUser+" "+message);
    })
}
