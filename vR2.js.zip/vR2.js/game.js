include('retos.js');
include('verdad.js');
include('users.js');
include('event.js');
include('castigo.js');
include('config.js');

var game = false;
var counter = false;
var vote = 0;


function sendVoto(num){
    vote += num;
    sendAllMessage(" tiene "+vote+" hasta ahora")
}

function startGame(){
    if(Players.length>=2){
        print('El juego comenzara en unos instantes 10s')
        if(game===false)
        delayAction(10000,SELECT_PLAYER)
        else
        print('El juego ya ha empesado pones unirte con el comando #unirme')
    } else {
        print('Insuficiente jugadores para iniciar el juego')
    }
}

function stopGame(){
    vote =0;
    counter=0;
    game=false;
    currentUser=false;
    currentAction=false;
    infractores=[];
    baneados=[];
    Players=[];
    print('El juego se ha detenido con éxito');
    print('Los bans, y infraciones se restablecieron a 0');
    print('Para volver a jugar #starGame');
    print('Todos los jugadores tienen que volver a unirse');
}



function delayAction(time,action){
    var timer = new Timer();
    timer.interval=time;
    timer.oncomplete = function(){
        if(game===false)
         game=true;
        currentAction = action;
        timer.stop();
    }
    timer.start();
}


function onTimer(){
    // CMD_EVENT = {
    //     SELECT_PLAYER: false,
    //     SEND_OPTION : false,
    //     GET_REQUEST:false,
    //     CHANGE_PLAYER:false,
    //     SEND_RETO:false,
    //     SEND_VERDAD:false,
    //     GET_RESPONSE:false,
    //     SEND_VOTE:false,
    //     CHECK_VOTE:false,
    // }
    if(game===true){
        switch (currentAction) {
          case SELECT_PLAYER:
            getUser();
            currentAction = SEND_OPTION;
            return;
          case SEND_OPTION:
            sendOption();
            return
          case GET_REQUEST:
            if (counter) {
              counter = counter - 1;
              return;
            } else {
              currentAction = CHANGE_PLAYER;
            }
          case CHANGE_PLAYER:
            changePlayer();
            return;

          case SEND_RETO:
            sendMessage(getReto());
            return
          case SEND_VERDAD:
            sendMessage(getVerdad());
            return
          case GET_RESPONSE:
            if(counter){
                counter = counter - 1;
                return;
             } else {
                sendAllMessage('ha comenzado la votación');
                counter=TIEMPO_VOTACION;
                vote=0;
                currentAction = SEND_VOTE;
                return;
              }

          case SEND_VOTE:
            if(counter){
                counter = counter -1;
                return;
            } else {
                currentAction = CHECK_VOTE;
                return
            }

          case CHECK_VOTE:
            if(vote < 0){
                sendAllMessage(' no hay conseguido los voto necesarios, sera penalizado con una infración.');
                // addInfracion(currentUser);
            } else {
                sendAllMessage(' ha cumplido con juego');
            }

            currentAction = SELECT_PLAYER;
            return;

            default: 
            return
        }
    }

}