include('game.js');
include('users.js');
include('event.js');

function onTextBefore(userobj, text) {
    if(currentAction===GET_REQUEST){
        if(userobj.name === currentUser){
            if(text.toLowerCase().contains('verdad')){
                currentAction = SEND_VERDAD;
                return text
            } 
            if(text.toLowerCase().contains('reto')){
                currentAction = SEND_RETO;
                return text
            }
        }
    }
    return text
}
