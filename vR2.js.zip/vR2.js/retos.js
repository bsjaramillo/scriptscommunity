
var GlobalReto = [];


function loadRetos(){
    if(File.exists('retos.json')){
     var fs  = File.load('retos.json');
     GlobalReto = JSON.parse(fs);
    } else {
        print("# Error no existe retos.json en la carpeta data");
    }
}


function saveRetos(){
    if(File.exists('retos.json')){
        File.save('retos.json',JSON.stringify(GlobalReto));
        print('Retos guardados. Total de retos: '+GlobalReto.length);
    }
}


function addReto(newReto){
    if(newReto.length>4){
        GlobalReto.push(newReto);
        saveRetos();
    } else{
        print('El reto es demasiado corto.');
    }
}

function remReto(id){
    if(GlobalReto.length > id){
        GlobalReto = GlobalReto.filter(function(reto,index){
            if(index!==parseInt(id)){
                return reto
            }  })

        print("El reto con el id: "+id+" ha sido eliminado");
        saveRetos();
    } else {
        print("Id no valida, profavor revisar la lista primero.");
    }

}

function listRetos(){
    if(GlobalReto.length)
    GlobalReto.forEach(function(reto,index){
        print(index+".-    "+reto);
    });
    else print('No hay ningun reto en la lista');
}


function getReto(){
    var index = Math.floor(Math.random()*GlobalReto.length);
    return GlobalReto[index];
}

loadRetos();