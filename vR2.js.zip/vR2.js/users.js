var Players = [];
var infraccion={}
var currentUser;

function addUser(name){
    var isExists = Players.some(
        function(username) { 
            return username===name
        });
 if(isExists) return print(user(name),"Ya estas dentro de la lista")
  else{
    Players.push(name);
    print("\x06"+name+" se unio al verdad o reto sin miedo al éxito");
  }
}

function remUser(name){
    Players = Players.filter(function(username){
        return username !== name 
    });
    print(user(name),' ya no estas en la partida.');
}


function resetUser(){
    Players = [];
}


function getUser(){
    var index = Math.floor(Math.random()*Players.length);
    currentUser = Players[index];
    return currentUser
}


