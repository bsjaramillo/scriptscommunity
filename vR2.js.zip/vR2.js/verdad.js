var GlobalVerdad = [];


function loadVerdades(){
    if(File.exists('verdad.json')){
     var fs  = File.load('verdad.json');
     GlobalVerdad = JSON.parse(fs);
    } else {
        print("# Error no existe verdad.json en la carpeta data");
    }
}


function saveVerdades(){
    if(File.exists('verdad.json')){
        File.save('verdad.json',JSON.stringify(GlobalVerdad));
        print('Preguntas guardadas. Total de preguntas: '+GlobalVerdad.length);
    }
}


function addVerdad(newVerdad){
    if(newVerdad.length>4){
        GlobalVerdad.push(newVerdad);
        saveVerdades();
    } else{
        print('La pregunta es demasiado corto.');
    }
}

function listVerdades(){
    if(GlobalVerdad.length)
    GlobalVerdad.forEach(function(verdad,index){
        print(index+".-    "+verdad);
    });
    else print('No hay ningun pregunta en la lista');
}

function remVerdad(id){
    if(GlobalVerdad.length > id){
        GlobalVerdad = GlobalVerdad.filter(function(verdad,index){
            if(index!==parseInt(id)){
                return verdad
            }
        })
        print("El reto con el id: "+id+" ha sido eliminado");
        saveVerdades();
    } else {
        print("Id no valida, profavor revisar la lista primero.");
    }
    
}

function getVerdad(){
    var index = Math.floor(Math.random()*GlobalVerdad.length);
    return GlobalVerdad[index];
}

loadVerdades();