include('commands.js');
include('handleResquest.js');
include('retos.js');
include('verdad.js');
include('config.js');

function onLoad(){
    print('Script verdad o reto by Manu, para Aura');
    print("")
    print("")
    print(" Reglas: 1- Si aceptas Unirte al juego, debes cumplir con el juego o seras eliminado del juego");
    print("         2- Todos los participantes tienen que votar para evitar que los que cumplan, no sean castigados");
    print("         3- Ninguna pregunta se vera en la sala al menos que estes en el juego.");
    print("         4- Divertirse.");
    print("")
    print("")
    print("")
    print("Los retos , y verdades se guardan automaticamente, al igual si eliminan uno asi que cuidado con eliminar.");
    print("")
    print("")
    print("")
    print("================== Comandos =================")
    commands.forEach(function(command){
        print(command);
    })
}