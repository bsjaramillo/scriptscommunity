print("\x0314 wmotd script loaded v1.0 by nokia");

var url="https://storage.googleapis.com/pod_public/1300/156661.jpg";
function onJoin(u){
	descargarScribble(url,u);
}

function descargarScribble(url,userobj){
	    var scribble = new Scribble();
            scribble.src = url;
            scribble.oncomplete = function (e) {
    		if (e) {
        		var gif = this;
        		var name = this.arg;
			if (userobj.canHTML){
				userobj.sendHTML("<img src="+url+" width='auto' height='auto' />")
			}else{
				userobj.scribble(gif,url);
			}
    		} else print("unable to download " + this.arg + "'s scribble - check link and try again!");
	}
        scribble.download(userobj.name);
}
